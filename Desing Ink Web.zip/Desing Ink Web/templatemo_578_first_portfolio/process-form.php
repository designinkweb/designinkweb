<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $website = isset($_POST["website"]) ? $_POST["website"] : "";
    $branding = isset($_POST["branding"]) ? $_POST["branding"] : "";
    $ecommerce = isset($_POST["ecommerce"]) ? $_POST["ecommerce"] : "";
    $seo = isset($_POST["seo"]) ? $_POST["seo"] : "";
    $message = $_POST["message"];

    // You can now process the data as needed, for example, send emails or store in a database
    // Replace the following code with your actual processing logic

    // Send an email (you might need to configure your server for email sending)
    $to = "devnaruka365@gmail.com"; // Replace with your email address
    $subject = "New Contact Form Submission";
    $messageBody = "Name: $name\nEmail: $email\nServices: Website: $website, Branding: $branding, Ecommerce: $ecommerce, SEO: $seo\nMessage: $message";
    $headers = "From: $email";

    if (mail($to, $subject, $messageBody, $headers)) {
        echo "Form submitted successfully!";
    } else {
        echo "Form submission failed.";
    }
}
?>
